export const enviroments = {
    baseUrl: 'http://tuabuela:3000'
}