export const enviroments = {
    baseUrl: 'http://localhost:3000'
}