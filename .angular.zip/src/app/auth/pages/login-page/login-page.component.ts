import { Component } from '@angular/core';

@Component({
  selector: 'app-login-page',
  standalone: false,
  
  templateUrl: './login-page.component.html',
  styles: ``
})
export class LoginPageComponent {

}
